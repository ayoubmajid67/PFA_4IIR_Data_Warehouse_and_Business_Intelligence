# China_map_json
geojson&amp;topojson for PowerBI

适用于PowerBI中形状地图的中国省市划分地图
